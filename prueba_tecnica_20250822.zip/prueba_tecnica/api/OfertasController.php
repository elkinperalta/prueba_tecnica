<?php
require_once __DIR__.'/db.php';
require_once __DIR__.'/middleware.php';

function crear_oferta() {
    $user = require_auth();
    $input = json_decode(file_get_contents('php://input'), true) ?? [];

    $solicitud_id = (int)($input['solicitud_id'] ?? 0);
    $producto = trim($input['producto'] ?? '');
    $cantidad = (int)($input['cantidad'] ?? 0);
    $precio = (float)($input['precio_unitario'] ?? 0);
    $tiempo = trim($input['tiempo_entrega'] ?? '');
    $observaciones = trim($input['observaciones'] ?? '');

    if (!$solicitud_id || !$producto || !$cantidad || !$precio) {
        json_response(['error'=>'Datos incompletos'],422);
    }

    try {
        $pdo = db();
        $stmt = $pdo->prepare("CALL sp_crear_oferta(:solicitud_id,:proveedor_id,:observaciones,:producto,:cantidad,:precio_unitario,:tiempo_entrega)");
        $stmt->execute([
            ':solicitud_id'=>$solicitud_id,
            ':proveedor_id'=>$user['id'],
            ':observaciones'=>$observaciones,
            ':producto'=>$producto,
            ':cantidad'=>$cantidad,
            ':precio_unitario'=>$precio,
            ':tiempo_entrega'=>$tiempo
        ]);
        $row = $stmt->fetch();
        json_response(['ok'=>true,'oferta_id'=>$row['oferta_id']],201);
    } catch (Throwable $e) {
        json_response(['error'=>'Error al crear oferta','detail'=>$e->getMessage()],500);
    }
}

function listar_ofertas($solicitud_id) {
    $user = require_auth();

    try {
        $pdo = db();
        $stmt = $pdo->prepare("CALL sp_consultar_ofertas(:solicitud_id)");
        $stmt->execute([':solicitud_id'=>$solicitud_id]);
        $rows = $stmt->fetchAll();
        json_response(['ofertas'=>$rows]);
    } catch (Throwable $e) {
        json_response(['error'=>'Error al consultar ofertas','detail'=>$e->getMessage()],500);
    }
}
?>
