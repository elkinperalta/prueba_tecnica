<?php
require_once __DIR__.'/db.php';
require_once __DIR__.'/middleware.php';

function registrar_decision() {
    $user = require_auth();
    $input = json_decode(file_get_contents('php://input'), true) ?? [];

    $oferta_id = (int)($input['oferta_id'] ?? 0);
    $decision = strtoupper(trim($input['decision'] ?? ''));
    $comentario = trim($input['comentario'] ?? '');

    if (!$oferta_id || !in_array($decision,['ACEPTADA','RECHAZADA','CONTRAOFERTA'],true)) {
        json_response(['error'=>'Datos inválidos'],422);
    }

    try {
        $pdo = db();
        $stmt = $pdo->prepare("CALL sp_registrar_decision(:oferta_id,:cliente_id,:decision,:comentario)");
        $stmt->execute([
            ':oferta_id'=>$oferta_id,
            ':cliente_id'=>$user['id'],
            ':decision'=>$decision,
            ':comentario'=>$comentario
        ]);
        json_response(['ok'=>true]);
    } catch (Throwable $e) {
        json_response(['error'=>'Error al registrar decisión','detail'=>$e->getMessage()],500);
    }
}

function listar_decisiones() {
    $user = require_auth();
    try {
        $pdo = db();
        $stmt = $pdo->prepare("CALL sp_consultar_decisiones(:cliente_id)");
        $stmt->execute([':cliente_id'=>$user['id']]);
        $rows = $stmt->fetchAll();
        json_response(['decisiones'=>$rows]);
    } catch (Throwable $e) {
        json_response(['error'=>'Error al consultar decisiones','detail'=>$e->getMessage()],500);
    }
}
?>
