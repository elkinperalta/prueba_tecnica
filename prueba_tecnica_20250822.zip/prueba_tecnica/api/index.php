<?php
require_once __DIR__.'/middleware.php';

cors_headers();
if ($_SERVER['REQUEST_METHOD']==='OPTIONS') { http_response_code(204); exit; }

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Quitar el prefijo "/prueba_tecnica"
$basePath = '/prueba_tecnica';
if (strpos($path, $basePath) === 0) {
    $path = substr($path, strlen($basePath));
}

switch (true) {

    // 🔹 Auth
    case $path === '/api/auth/login' && $_SERVER['REQUEST_METHOD']==='POST':
        require_once __DIR__.'/AuthController.php'; login(); break;

    case $path === '/api/auth/register' && $_SERVER['REQUEST_METHOD']==='POST':
        require_once __DIR__.'/RegisterController.php'; register(); break;

    case $path === '/api/auth/refresh' && $_SERVER['REQUEST_METHOD']==='POST':
        require_once __DIR__.'/AuthController.php'; refresh(); break;

    case $path === '/api/auth/logout-all' && $_SERVER['REQUEST_METHOD']==='POST':
        require_once __DIR__.'/AuthController.php'; logout_all(); break;

    // 🔹 Clientes
    case $path === '/api/clientes/mis-datos' && $_SERVER['REQUEST_METHOD']==='GET':
        require_once __DIR__.'/UsersController.php'; get_mis_datos_cliente(); break;

    case $path === '/api/solicitudes/crear' && $_SERVER['REQUEST_METHOD']==='POST':
        require_once __DIR__.'/SolicitudesController.php'; crear_solicitud(); break;

    case $path === '/api/solicitudes/listar' && $_SERVER['REQUEST_METHOD']==='GET':
        require_once __DIR__.'/SolicitudesController.php'; listar_solicitudes(); break;

    case $path === '/api/decisiones/registrar' && $_SERVER['REQUEST_METHOD']==='POST':
        require_once __DIR__.'/DecisionesController.php'; registrar_decision(); break;

    case $path === '/api/decisiones/listar' && $_SERVER['REQUEST_METHOD']==='GET':
        require_once __DIR__.'/DecisionesController.php'; listar_decisiones(); break;

    // 🔹 Proveedores
    case $path === '/api/proveedores/panel' && $_SERVER['REQUEST_METHOD']==='GET':
        require_once __DIR__.'/UsersController.php'; get_panel_proveedor(); break;

    case $path === '/api/ofertas/crear' && $_SERVER['REQUEST_METHOD']==='POST':
        require_once __DIR__.'/OfertasController.php'; crear_oferta(); break;

    case (preg_match('#^/api/ofertas/listar/(\d+)$#', $path, $matches) ? true : false) && $_SERVER['REQUEST_METHOD']==='GET':
        require_once __DIR__.'/OfertasController.php'; listar_ofertas($matches[1]); break;

    // 🔹 Default 404
    default:
        http_response_code(404);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error'=>'No encontrado']);
}

?>
