<?php
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

require_once __DIR__.'/vendor/autoload.php';

function cors_headers() {
  $cfg = require __DIR__.'/config.php';
  header("Access-Control-Allow-Origin: {$cfg['cors']['origin']}");
  header("Access-Control-Allow-Headers: {$cfg['cors']['headers']}");
  header("Access-Control-Allow-Methods: {$cfg['cors']['methods']}");
}

function json_response($data, int $code = 200) {
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($data, JSON_UNESCAPED_UNICODE);
  exit;
}

function issue_tokens(array $user): array {
  $cfg = require __DIR__.'/config.php';
  $now = time();
  $accessPayload = [
    'iss' => $cfg['jwt']['issuer'],
    'aud' => $cfg['jwt']['audience'],
    'iat' => $now,
    'nbf' => $now,
    'exp' => $now + $cfg['jwt']['access_ttl'],
    'sub' => (string)$user['id'],
    'role'=> $user['rol'],
    'email'=> $user['email']
  ];
  $access = JWT::encode($accessPayload, $cfg['jwt']['secret'], 'HS256');

  // refresh como string aleatoria almacenada con hash
  $refresh_plain = bin2hex(random_bytes(32));
  $refresh_hash  = hash('sha256', $refresh_plain);
  $expires_at = date('Y-m-d H:i:s', $now + $cfg['jwt']['refresh_ttl']);

  $pdo = db();
  $stmt = $pdo->prepare("CALL sp_guardar_refresh_token(:uid, :th, :exp)");
  $stmt->execute([':uid'=>$user['id'], ':th'=>$refresh_hash, ':exp'=>$expires_at]);

  return ['access_token'=>$access, 'refresh_token'=>$refresh_plain, 'expires_in'=>$cfg['jwt']['access_ttl']];
}

function require_auth(): array {
  $cfg = require __DIR__.'/config.php';
  $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
  if (!preg_match('/Bearer\s+(.+)/i', $auth, $m)) {
    json_response(['error'=>'Token requerido'], 401);
  }
  $token = trim($m[1]);
  try {
    $decoded = Firebase\JWT\JWT::decode($token, new Key($cfg['jwt']['secret'], 'HS256'));
    // Convert stdClass a array sencillo
    return [
      'id'    => (int)$decoded->sub,
      'rol'   => $decoded->role ?? null,
      'email' => $decoded->email ?? null
    ];
  } catch (Throwable $e) {
    json_response(['error'=>'Token inválido o expirado','detail'=>$e->getMessage()], 401);
  }
}

function require_role(array $rolesPermitidos, array $userCtx) {
  if (!in_array($userCtx['rol'], $rolesPermitidos, true)) {
    json_response(['error'=>'No autorizado (rol)'], 403);
  }
}
?>
