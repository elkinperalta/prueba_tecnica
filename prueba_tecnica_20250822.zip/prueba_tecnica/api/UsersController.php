<?php
require_once __DIR__.'/db.php';
require_once __DIR__.'/middleware.php';

function get_mis_datos_cliente() {
  $user = require_auth();
  require_role(['CLIENTE','ADMIN'], $user);

  $pdo = db();
  $stmt = $pdo->prepare("SELECT u.id, u.email, c.nombre, c.telefono
                         FROM usuarios u
                         JOIN clientes c ON c.id = u.id
                         WHERE u.id = :id LIMIT 1");
  $stmt->execute([':id'=>$user['id']]);
  $data = $stmt->fetch();
  json_response($data ?: []);
}

function get_panel_proveedor() {
  $user = require_auth();
  require_role(['PROVEEDOR','ADMIN'], $user);

  // Aquí pondrías la lógica del panel del proveedor
  json_response(['mensaje'=>'Hola proveedor', 'user'=>$user]);
}

?>
