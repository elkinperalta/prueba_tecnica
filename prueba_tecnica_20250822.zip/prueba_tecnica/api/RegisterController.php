<?php
require_once __DIR__.'/db.php';
require_once __DIR__.'/middleware.php';

function register() {
  $input = json_decode(file_get_contents('php://input'), true) ?? [];

  $email = trim(strtolower($input['email'] ?? ''));
  $password = (string)($input['password'] ?? '');
  $rol = strtoupper($input['rol'] ?? 'CLIENTE'); // CLIENTE | PROVEEDOR

  if (!$email || !$password) {
    json_response(['error'=>'Email y contraseña requeridos'], 422);
  }
  if (!in_array($rol, ['CLIENTE','PROVEEDOR'], true)) {
    json_response(['error'=>'Rol inválido'], 422);
  }

  $hash = password_hash($password, PASSWORD_DEFAULT);

  try {
    $pdo = db();
    $stmt = $pdo->prepare("CALL sp_crear_usuario(:email, :ph, :rol)");
    $stmt->execute([':email'=>$email, ':ph'=>$hash, ':rol'=>$rol]);
    $userId = $stmt->fetch()['user_id'] ?? null;
    while ($stmt->nextRowset()) {}

    if ($rol === 'CLIENTE') {
      $stmt2 = $pdo->prepare("INSERT INTO clientes(id,nombre) VALUES(:id,:nombre)");
      $stmt2->execute([':id'=>$userId, ':nombre'=>$input['nombre'] ?? '']);
    } elseif ($rol === 'PROVEEDOR') {
      $stmt2 = $pdo->prepare("INSERT INTO proveedores(id,razon_social) VALUES(:id,:rs)");
      $stmt2->execute([':id'=>$userId, ':rs'=>$input['razon_social'] ?? '']);
    }

    json_response(['ok'=>true,'user_id'=>$userId],201);

  } catch (Throwable $e) {
    if (str_contains($e->getMessage(),'Duplicate entry')) {
      json_response(['error'=>'El correo ya está registrado'],409);
    }
    json_response(['error'=>'Error al registrar','detail'=>$e->getMessage()],500);
  }
}
?>
