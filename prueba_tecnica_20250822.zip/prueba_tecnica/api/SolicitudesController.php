<?php
require_once __DIR__.'/db.php';
require_once __DIR__.'/middleware.php';

function crear_solicitud() {
    $user = require_auth();
    $input = json_decode(file_get_contents('php://input'), true) ?? [];

    $descripcion = trim($input['descripcion'] ?? '');
    $producto = trim($input['producto'] ?? '');
    $cantidad = (int)($input['cantidad'] ?? 0);
    $unidad = trim($input['unidad'] ?? '');

    if (!$descripcion || !$producto || !$cantidad) {
        json_response(['error'=>'Datos incompletos'],422);
    }

    try {
        $pdo = db();
        $stmt = $pdo->prepare("CALL sp_crear_solicitud(:cliente_id,:descripcion,:producto,:cantidad,:unidad)");
        $stmt->execute([
            ':cliente_id'=>$user['id'],
            ':descripcion'=>$descripcion,
            ':producto'=>$producto,
            ':cantidad'=>$cantidad,
            ':unidad'=>$unidad
        ]);
        $row = $stmt->fetch();
        json_response(['ok'=>true,'solicitud_id'=>$row['solicitud_id']],201);
    } catch (Throwable $e) {
        json_response(['error'=>'Error al crear solicitud','detail'=>$e->getMessage()],500);
    }
}

function listar_solicitudes() {
    $user = require_auth();

    try {
        $pdo = db();
        $stmt = $pdo->prepare("CALL sp_consultar_solicitudes(:cliente_id)");
        $stmt->execute([':cliente_id'=>$user['id']]);
        $rows = $stmt->fetchAll();
        json_response(['solicitudes'=>$rows]);
    } catch (Throwable $e) {
        json_response(['error'=>'Error al consultar solicitudes','detail'=>$e->getMessage()],500);
    }
}
?>
