<?php
require_once __DIR__.'/db.php';
require_once __DIR__.'/middleware.php';

function login() {
  $input = json_decode(file_get_contents('php://input'), true) ?? [];
  $email = trim(strtolower($input['email'] ?? ''));
  $password = (string)($input['password'] ?? '');

  if (!$email || !$password) json_response(['error'=>'Email y password requeridos'], 422);

  $pdo = db();
  $stmt = $pdo->prepare("CALL sp_login_usuario(:email)");
  $stmt->execute([':email'=>$email]);
  $user = $stmt->fetch();
  // consume results restantes de CALL
  while ($stmt->nextRowset()) {}

  if (!$user || !$user['is_active']) {
    json_response(['error'=>'Credenciales inválidas'], 401);
  }
  if (!password_verify($password, $user['password_hash'])) {
    json_response(['error'=>'Credenciales inválidas'], 401);
  }

  $tokens = issue_tokens($user);
  json_response([
    'user'=> ['id'=>(int)$user['id'],'email'=>$user['email'],'rol'=>$user['rol']],
    'tokens'=>$tokens
  ]);
}

function refresh() {
  $input = json_decode(file_get_contents('php://input'), true) ?? [];
  $user_id = (int)($input['user_id'] ?? 0);
  $refresh_plain = (string)($input['refresh_token'] ?? '');
  if (!$user_id || !$refresh_plain) json_response(['error'=>'Datos incompletos'], 422);

  $refresh_hash = hash('sha256', $refresh_plain);
  $pdo = db();

  // validar token
  $stmt = $pdo->prepare("CALL sp_validar_refresh_token(:uid, :th)");
  $stmt->execute([':uid'=>$user_id, ':th'=>$refresh_hash]);
  $row = $stmt->fetch();
  while ($stmt->nextRowset()) {}

  if (!$row || (int)$row['revoked'] === 1 || strtotime($row['expires_at']) <= time()) {
    json_response(['error'=>'Refresh token inválido'], 401);
  }

  // cargar usuario
  $stmtU = $pdo->prepare("SELECT id,email,rol,is_active FROM usuarios WHERE id = :id LIMIT 1");
  $stmtU->execute([':id'=>$user_id]);
  $user = $stmtU->fetch();
  if (!$user || !$user['is_active']) json_response(['error'=>'Usuario inactivo'], 401);

  $tokens = issue_tokens($user);
  json_response(['tokens'=>$tokens]);
}

function logout_all() {
  $user = require_auth(); // necesita access token válido
  $pdo = db();
  $stmt = $pdo->prepare("CALL sp_revocar_refresh_tokens(:uid)");
  $stmt->execute([':uid'=>$user['id']]);
  json_response(['ok'=>true]);
}
?>
