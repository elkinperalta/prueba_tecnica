<?php
// Configuración básica
return [
  'db' => [
    'host' => '127.0.0.1',
    'port' => 3306,
    'name' => 'prueba_tecnica',
    'user' => 'toor',
    'pass' => 'pruebatecnica',
    'charset' => 'utf8mb4',
  ],
  'jwt' => [
    'secret' => 'XoYv23fg6u6Bs4qU94HEaEFc',
    'issuer' => 'http://localhost/prueba_tecnica/',
    'audience' => 'http://localhost/prueba_tecnica',
    'access_ttl' => 15 * 60,      // 15 minutos
    'refresh_ttl' => 30 * 24 * 60 * 60 // 30 días
  ],
  'cors' => [
    'origin' => '*', // ajusta según tu front
    'headers' => 'Content-Type, Authorization',
    'methods' => 'GET, POST, PUT, PATCH, DELETE, OPTIONS'
  ]
];
?>
